export default function PageHeader({ title, subtitle, actions }) {
  return <div className="page-header"><div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{actions && <div>{actions}</div>}</div>;
}
